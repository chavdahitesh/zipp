import { Component } from '@angular/core';

@Component({
  selector: 'app-hidden-labels',
  templateUrl: './hidden-labels.component.html',
  styleUrls: ['./hidden-labels.component.scss']
})
export class HiddenLabelsComponent{
}
