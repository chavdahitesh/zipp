import { Component, ViewChild } from '@angular/core';
import { NgForm, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from "@angular/router";
import { AuthService } from '../../../shared/auth/auth.service'
import { ToastrService } from 'ngx-toastr';
@Component({
    selector: 'app-login-page',
    templateUrl: './login-page.component.html',
    styleUrls: ['./login-page.component.scss']
})

export class LoginPageComponent {

    @ViewChild('f', { static: false }) loginForm: NgForm;
    test_token = "1234";
    constructor(private router: Router,
        private route: ActivatedRoute,
        private authService: AuthService,
        private toast:ToastrService) { }

    // On submit button click
    onSubmit() {
        this.loginForm.reset();
    }
    // On Forgot password link click
    onForgotPassword() {
        this.router.navigate(['forgotpassword'], { relativeTo: this.route.parent });
    }
    // On registration link click
    onRegister() {
        this.router.navigate(['register'], { relativeTo: this.route.parent });
    }
    adminlogin(email, password) {
        let data = {
            'email': email,
            'password': password
        }
        // this.authService.login(data).subscribe(res => {
        //     if (res && res['code']== 200) {
        //         localStorage.setItem('_logintoken', this.test_token)
        //         this.router.navigate(['dashboard/world'])
        //         this.toast.success(res['success']);
        //     }
        //     else{
        //         this.toast.warning(res['success'])
        //     }
        // })
    }
}
