import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { from } from 'rxjs';
import { environment } from '../../../environments/environment'
import { Observable, throwError, forkJoin, BehaviorSubject } from "rxjs";
import { catchError } from 'rxjs/operators';

@Injectable()
export class AuthService {
  token: string;
  // private url = environment.api.baseurl;
  constructor(private http: HttpClient,
    private route: Router) { }

  // signupUser(email: string, password: string) {
  //   //your code for signing up the new user
  // }

  // signinUser(email: string, password: string) {
  //   //your code for checking credentials and getting tokens for for signing in user
  // }

  // logout() {
  //   localStorage.removeItem('_logintoken')
  //   this.route.navigateByUrl('users/login')
  //   return true
  // }
  // login(obj) {
  //   this.token = localStorage.getItem('_logintoken');
  //   return this.http.post(`${this.url}/login`, obj)
  //     .pipe(catchError(this.handleError));
  // }

  // getToken() {
  //   return this.token;
  // }

  isAuthenticated() {
    // here you can check if user is authenticated or not through his token 
    
    return true
    
  }

  /* Handle Global Error */
  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }
}
