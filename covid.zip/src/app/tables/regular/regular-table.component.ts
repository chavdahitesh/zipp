import { Component } from '@angular/core';

@Component({
    selector: 'app-regular-table',
    templateUrl: './regular-table.component.html',
    styleUrls: ['./regular-table.component.scss']
})

export class RegularTableComponent  {

}