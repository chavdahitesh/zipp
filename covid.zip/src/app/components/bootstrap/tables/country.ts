export interface Country {
  id: number;
  name: string;
  flag: string;
  area: number;
  population: number;
}
