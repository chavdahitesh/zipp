export const environment = {
  production: true,
  api:{
    baseurl:'https://covid19-server.chrismichael.now.sh/api/v1'
    
  }
};
